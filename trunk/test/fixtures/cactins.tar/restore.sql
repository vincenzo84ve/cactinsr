create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

DROP INDEX public.unique_schema_migrations;
ALTER TABLE ONLY public.umedidas DROP CONSTRAINT umedidas_pkey;
ALTER TABLE ONLY public.ubicaciones DROP CONSTRAINT ubicaciones_pkey;
ALTER TABLE ONLY public.proveedors DROP CONSTRAINT proveedors_pkey;
ALTER TABLE ONLY public.personas DROP CONSTRAINT personas_pkey;
ALTER TABLE ONLY public.marcas DROP CONSTRAINT marcas_pkey;
ALTER TABLE ONLY public.fichas DROP CONSTRAINT fichas_pkey;
ALTER TABLE ONLY public.facturas DROP CONSTRAINT facturas_pkey;
ALTER TABLE ONLY public.existencias DROP CONSTRAINT existencias_pkey;
ALTER TABLE ONLY public.cgenerals DROP CONSTRAINT cgenerals_pkey;
ALTER TABLE ONLY public.careas DROP CONSTRAINT careas_pkey;
ALTER TABLE ONLY public.asignados DROP CONSTRAINT asignados_pkey;
ALTER TABLE ONLY public.activos DROP CONSTRAINT activos_pkey;
ALTER TABLE public.umedidas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ubicaciones ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.proveedors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.personas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.marcas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.fichas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.facturas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.existencias ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.cgenerals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.careas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.asignados ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.activos ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.umedidas_id_seq;
DROP TABLE public.umedidas;
DROP SEQUENCE public.ubicaciones_id_seq;
DROP TABLE public.ubicaciones;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.proveedors_id_seq;
DROP TABLE public.proveedors;
DROP SEQUENCE public.personas_id_seq;
DROP TABLE public.personas;
DROP SEQUENCE public.marcas_id_seq;
DROP TABLE public.marcas;
DROP SEQUENCE public.fichas_id_seq;
DROP TABLE public.fichas;
DROP SEQUENCE public.facturas_id_seq;
DROP TABLE public.facturas;
DROP SEQUENCE public.existencias_id_seq;
DROP TABLE public.existencias;
DROP SEQUENCE public.cgenerals_id_seq;
DROP TABLE public.cgenerals;
DROP SEQUENCE public.careas_id_seq;
DROP TABLE public.careas;
DROP SEQUENCE public.asignados_id_seq;
DROP TABLE public.asignados;
DROP SEQUENCE public.activos_id_seq;
DROP TABLE public.activos;
DROP PROCEDURAL LANGUAGE plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: postgres
--

CREATE PROCEDURAL LANGUAGE plpgsql;


ALTER PROCEDURAL LANGUAGE plpgsql OWNER TO postgres;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: activos; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE activos (
    id integer NOT NULL,
    descripcion character varying(255),
    marca_id integer,
    modelo character varying(255),
    es_equipo boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.activos OWNER TO postgres;

--
-- Name: activos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE activos_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.activos_id_seq OWNER TO postgres;

--
-- Name: activos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE activos_id_seq OWNED BY activos.id;


--
-- Name: activos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('activos_id_seq', 44, true);


--
-- Name: asignados; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE asignados (
    id integer NOT NULL,
    fecha date,
    persona_id integer,
    existencia_id integer,
    esta_activo boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.asignados OWNER TO postgres;

--
-- Name: asignados_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE asignados_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.asignados_id_seq OWNER TO postgres;

--
-- Name: asignados_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE asignados_id_seq OWNED BY asignados.id;


--
-- Name: asignados_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('asignados_id_seq', 1, true);


--
-- Name: careas; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE careas (
    id integer NOT NULL,
    nombre character varying(255),
    cgeneral_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.careas OWNER TO postgres;

--
-- Name: careas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE careas_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.careas_id_seq OWNER TO postgres;

--
-- Name: careas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE careas_id_seq OWNED BY careas.id;


--
-- Name: careas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('careas_id_seq', 2, true);


--
-- Name: cgenerals; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE cgenerals (
    id integer NOT NULL,
    nombre character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.cgenerals OWNER TO postgres;

--
-- Name: cgenerals_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cgenerals_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.cgenerals_id_seq OWNER TO postgres;

--
-- Name: cgenerals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cgenerals_id_seq OWNED BY cgenerals.id;


--
-- Name: cgenerals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cgenerals_id_seq', 1, true);


--
-- Name: existencias; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE existencias (
    id integer NOT NULL,
    factura_id integer,
    activo_id integer,
    cantidad integer,
    saldo integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    serial character varying(255),
    es_asignado boolean DEFAULT false,
    esta_activo boolean DEFAULT false
);


ALTER TABLE public.existencias OWNER TO postgres;

--
-- Name: existencias_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE existencias_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.existencias_id_seq OWNER TO postgres;

--
-- Name: existencias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE existencias_id_seq OWNED BY existencias.id;


--
-- Name: existencias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('existencias_id_seq', 13, true);


--
-- Name: facturas; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE facturas (
    id integer NOT NULL,
    fecha timestamp without time zone,
    proveedor_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    factura integer,
    estado character varying(255) DEFAULT 'en proceso'::character varying
);


ALTER TABLE public.facturas OWNER TO postgres;

--
-- Name: facturas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE facturas_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.facturas_id_seq OWNER TO postgres;

--
-- Name: facturas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE facturas_id_seq OWNED BY facturas.id;


--
-- Name: facturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('facturas_id_seq', 8, true);


--
-- Name: fichas; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE fichas (
    id integer NOT NULL,
    fecha date,
    componente character varying(255),
    medida integer,
    umedida_id integer,
    activo_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.fichas OWNER TO postgres;

--
-- Name: fichas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE fichas_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.fichas_id_seq OWNER TO postgres;

--
-- Name: fichas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE fichas_id_seq OWNED BY fichas.id;


--
-- Name: fichas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('fichas_id_seq', 47, true);


--
-- Name: marcas; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE marcas (
    id integer NOT NULL,
    descripcion character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.marcas OWNER TO postgres;

--
-- Name: marcas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE marcas_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.marcas_id_seq OWNER TO postgres;

--
-- Name: marcas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE marcas_id_seq OWNED BY marcas.id;


--
-- Name: marcas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('marcas_id_seq', 2, true);


--
-- Name: personas; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE personas (
    id integer NOT NULL,
    cedula character varying(255),
    nombre character varying(255),
    apellido character varying(255),
    cargo character varying(255),
    carea_id integer,
    ubicacione_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.personas OWNER TO postgres;

--
-- Name: personas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE personas_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.personas_id_seq OWNER TO postgres;

--
-- Name: personas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE personas_id_seq OWNED BY personas.id;


--
-- Name: personas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('personas_id_seq', 2, true);


--
-- Name: proveedors; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE proveedors (
    id integer NOT NULL,
    nombre character varying(255),
    rif character varying(255),
    direccion character varying(255),
    contacto character varying(255),
    telefono character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.proveedors OWNER TO postgres;

--
-- Name: proveedors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE proveedors_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.proveedors_id_seq OWNER TO postgres;

--
-- Name: proveedors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE proveedors_id_seq OWNED BY proveedors.id;


--
-- Name: proveedors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('proveedors_id_seq', 1, true);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO postgres;

--
-- Name: ubicaciones; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ubicaciones (
    id integer NOT NULL,
    descripcion character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.ubicaciones OWNER TO postgres;

--
-- Name: ubicaciones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE ubicaciones_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ubicaciones_id_seq OWNER TO postgres;

--
-- Name: ubicaciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE ubicaciones_id_seq OWNED BY ubicaciones.id;


--
-- Name: ubicaciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('ubicaciones_id_seq', 3, true);


--
-- Name: umedidas; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE umedidas (
    id integer NOT NULL,
    descripcion character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.umedidas OWNER TO postgres;

--
-- Name: umedidas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE umedidas_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.umedidas_id_seq OWNER TO postgres;

--
-- Name: umedidas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE umedidas_id_seq OWNED BY umedidas.id;


--
-- Name: umedidas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('umedidas_id_seq', 8, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE activos ALTER COLUMN id SET DEFAULT nextval('activos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE asignados ALTER COLUMN id SET DEFAULT nextval('asignados_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE careas ALTER COLUMN id SET DEFAULT nextval('careas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE cgenerals ALTER COLUMN id SET DEFAULT nextval('cgenerals_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE existencias ALTER COLUMN id SET DEFAULT nextval('existencias_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE facturas ALTER COLUMN id SET DEFAULT nextval('facturas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE fichas ALTER COLUMN id SET DEFAULT nextval('fichas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE marcas ALTER COLUMN id SET DEFAULT nextval('marcas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE personas ALTER COLUMN id SET DEFAULT nextval('personas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE proveedors ALTER COLUMN id SET DEFAULT nextval('proveedors_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ubicaciones ALTER COLUMN id SET DEFAULT nextval('ubicaciones_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE umedidas ALTER COLUMN id SET DEFAULT nextval('umedidas_id_seq'::regclass);


--
-- Data for Name: activos; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: asignados; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: careas; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: cgenerals; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: existencias; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: facturas; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: fichas; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: marcas; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: personas; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: proveedors; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: ubicaciones; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: umedidas; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Name: activos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY activos
    ADD CONSTRAINT activos_pkey PRIMARY KEY (id);


--
-- Name: asignados_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY asignados
    ADD CONSTRAINT asignados_pkey PRIMARY KEY (id);


--
-- Name: careas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY careas
    ADD CONSTRAINT careas_pkey PRIMARY KEY (id);


--
-- Name: cgenerals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY cgenerals
    ADD CONSTRAINT cgenerals_pkey PRIMARY KEY (id);


--
-- Name: existencias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY existencias
    ADD CONSTRAINT existencias_pkey PRIMARY KEY (id);


--
-- Name: facturas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY facturas
    ADD CONSTRAINT facturas_pkey PRIMARY KEY (id);


--
-- Name: fichas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fichas
    ADD CONSTRAINT fichas_pkey PRIMARY KEY (id);


--
-- Name: marcas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY marcas
    ADD CONSTRAINT marcas_pkey PRIMARY KEY (id);


--
-- Name: personas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY personas
    ADD CONSTRAINT personas_pkey PRIMARY KEY (id);


--
-- Name: proveedors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY proveedors
    ADD CONSTRAINT proveedors_pkey PRIMARY KEY (id);


--
-- Name: ubicaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY ubicaciones
    ADD CONSTRAINT ubicaciones_pkey PRIMARY KEY (id);


--
-- Name: umedidas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY umedidas
    ADD CONSTRAINT umedidas_pkey PRIMARY KEY (id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

